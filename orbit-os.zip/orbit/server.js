import Fastify from "fastify";
import fastifyStatic from "@fastify/static";
import { createServer } from "node:http";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import wisp from "wisp-server-node";
import { uvPath } from "@titaniumnetwork-dev/ultraviolet";
import { epoxyPath } from "@mercuryworkshop/epoxy-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 8080;

// Fastify on top of a raw HTTP server so we can handle the Wisp websocket upgrade.
const fastify = Fastify({
  logger: false,
  serverFactory: (handler) =>
    createServer((req, res) => handler(req, res)).on("upgrade", (req, socket, head) => {
      if (req.url && req.url.endsWith("/wisp/")) wisp.routeRequest(req, socket, head);
      else socket.end();
    }),
});

fastify.register(fastifyStatic, { root: join(__dirname, "public"), decorateReply: true });
fastify.register(fastifyStatic, { root: uvPath, prefix: "/uv/", decorateReply: false });
fastify.register(fastifyStatic, { root: epoxyPath, prefix: "/epoxy/", decorateReply: false });
fastify.register(fastifyStatic, { root: baremuxPath, prefix: "/baremux/", decorateReply: false });

fastify.listen({ port: PORT, host: "0.0.0.0" }).then(() => {
  console.log(`\n  ORBIT is live →  http://localhost:${PORT}\n`);
});

const shutdown = () => { fastify.close(); process.exit(0); };
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
