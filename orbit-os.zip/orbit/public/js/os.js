/* ───────────── ORBIT OS ───────────── */
"use strict";

/* ═════════ helpers ═════════ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
function el(tag, attrs = {}, kids = []) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") n.className = v;
    else if (k === "html") n.innerHTML = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  for (const c of [].concat(kids)) n.append(c);
  return n;
}
const store = {
  get(k, d) { try { const v = localStorage.getItem("orbit." + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("orbit." + k, JSON.stringify(v)); } catch {} },
};
const uid = () => Math.random().toString(36).slice(2, 9);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

const I = {
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>',
  fwd: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>',
  reload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>',
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>',
  min: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg>',
  max: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>',
  globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
  full: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"/></svg>',
  unfull: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3v3a2 2 0 0 1-2 2H3M21 8h-3a2 2 0 0 1-2-2V3M3 16h3a2 2 0 0 1 2 2v3M16 21v-3a2 2 0 0 1 2-2h3"/></svg>',
  grid: '<svg class="grid-ico" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>',
};

/* ═════════ settings ═════════ */
const DEFAULTS = { accent: "#7c6cff", motion: true, intro: true, sfx: true, volume: 0.7, engine: "https://duckduckgo.com/?q=%s" };
const settings = Object.assign({}, DEFAULTS, store.get("settings", {}));
function applySettings() {
  document.documentElement.style.setProperty("--accent", settings.accent);
  store.set("settings", settings);
}
applySettings();

/* ═════════ sound effects (synthesized with WebAudio, no files) ═════════ */
const Sound = (() => {
  let ac = null, master, wet, last = {};
  function init() {
    if (ac) return ac;
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
    ac = new AC();
    master = ac.createGain(); master.connect(ac.destination);
    const lp = ac.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 9000; lp.connect(master);
    master.gain.value = 0;
    const d = ac.createDelay(1); d.delayTime.value = 0.13;
    const fb = ac.createGain(); fb.gain.value = 0.3; d.connect(fb); fb.connect(d);
    wet = ac.createGain(); wet.gain.value = 0.35; wet.connect(d); d.connect(lp);
    master.__dry = lp;
    return ac;
  }
  const out = () => master.__dry;
  function tone({ f = 440, f2 = null, t = 0, d = 0.15, type = "sine", v = 0.15, a = 0.006, send = 0 }) {
    const T = ac.currentTime + t, o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(f, T);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, T + d);
    g.gain.setValueAtTime(0.0001, T); g.gain.exponentialRampToValueAtTime(v, T + a); g.gain.exponentialRampToValueAtTime(0.0001, T + d);
    o.connect(g); g.connect(out());
    if (send) { const sg = ac.createGain(); sg.gain.value = send; g.connect(sg); sg.connect(wet); }
    o.start(T); o.stop(T + d + 0.05);
  }
  function whoosh({ f = 400, f2 = 3000, t = 0, d = 0.25, v = 0.07, q = 1.4 }) {
    const T = ac.currentTime + t, len = Math.ceil(ac.sampleRate * d), buf = ac.createBuffer(1, len, ac.sampleRate), ch = buf.getChannelData(0);
    for (let i = 0; i < len; i++) ch[i] = Math.random() * 2 - 1;
    const src = ac.createBufferSource(); src.buffer = buf;
    const bp = ac.createBiquadFilter(); bp.type = "bandpass"; bp.Q.value = q;
    bp.frequency.setValueAtTime(f, T); bp.frequency.exponentialRampToValueAtTime(f2, T + d);
    const g = ac.createGain(); g.gain.setValueAtTime(0.0001, T); g.gain.exponentialRampToValueAtTime(v, T + d * 0.35); g.gain.exponentialRampToValueAtTime(0.0001, T + d);
    src.connect(bp); bp.connect(g); g.connect(out()); src.start(T);
  }
  const arp = (notes, gap, o = {}) => notes.forEach((f, i) => tone({ f, t: i * gap, d: 0.35, v: 0.1, send: 0.5, ...o }));
  const BANK = {
    __unlock: () => {},
    click: () => tone({ f: 1900, f2: 1100, d: 0.05, type: "triangle", v: 0.07 }),
    hover: () => tone({ f: 2600, d: 0.03, v: 0.018 }),
    open: () => { whoosh({ f: 500, f2: 3500, d: 0.2, v: 0.04 }); tone({ f: 523, d: 0.28, v: 0.1, send: 0.5 }); tone({ f: 784, t: 0.07, d: 0.34, v: 0.1, send: 0.5 }); },
    close: () => { tone({ f: 659, f2: 392, d: 0.18, v: 0.09, send: 0.3 }); whoosh({ f: 2500, f2: 400, d: 0.18, v: 0.035 }); },
    minimize: () => { whoosh({ f: 2200, f2: 280, d: 0.24, v: 0.06 }); tone({ f: 420, f2: 240, d: 0.16, v: 0.05, type: "triangle" }); },
    restore: () => { whoosh({ f: 280, f2: 2400, d: 0.24, v: 0.06 }); tone({ f: 240, f2: 460, d: 0.16, v: 0.05, type: "triangle" }); },
    maximize: () => { whoosh({ f: 600, f2: 1800, d: 0.18, v: 0.045 }); tone({ f: 600, f2: 900, d: 0.1, v: 0.05, type: "triangle" }); },
    fullscreen: () => { whoosh({ f: 300, f2: 5000, d: 0.4, v: 0.07 }); arp([440, 660, 880, 1320], 0.05); },
    exitfull: () => { whoosh({ f: 4000, f2: 300, d: 0.35, v: 0.06 }); arp([1320, 880, 660, 440], 0.045, { v: 0.08 }); },
    dock: () => tone({ f: 480, f2: 880, d: 0.1, v: 0.08, send: 0.3 }),
    panel: () => { whoosh({ f: 400, f2: 3200, d: 0.3, v: 0.05 }); arp([587, 880], 0.07, { v: 0.07 }); },
    panelClose: () => { whoosh({ f: 3000, f2: 350, d: 0.25, v: 0.045 }); tone({ f: 660, f2: 440, d: 0.15, v: 0.06 }); },
    add: () => arp([523, 659, 784, 1047], 0.065, { v: 0.1 }),
    remove: () => { tone({ f: 320, f2: 140, d: 0.18, v: 0.1, type: "triangle" }); },
    tab: () => tone({ f: 720, f2: 1080, d: 0.07, v: 0.08, type: "triangle" }),
    tabClose: () => tone({ f: 620, f2: 400, d: 0.07, v: 0.07, type: "triangle" }),
    loaded: () => tone({ f: 1320, d: 0.14, v: 0.045, send: 0.4 }),
    notify: () => { tone({ f: 880, d: 0.4, v: 0.09, send: 0.6 }); tone({ f: 1318, t: 0.09, d: 0.45, v: 0.07, send: 0.6 }); },
    error: () => { tone({ f: 220, d: 0.14, v: 0.12, type: "sawtooth" }); tone({ f: 165, t: 0.13, d: 0.22, v: 0.12, type: "sawtooth" }); },
    menu: () => tone({ f: 1500, f2: 1000, d: 0.04, v: 0.05, type: "triangle" }),
    ready: () => arp([392, 494, 587, 784, 988], 0.09, { v: 0.09 }),
  };
  function play(name) {
    if (!settings.sfx || !BANK[name]) return;
    const n = performance.now(); if (last[name] && n - last[name] < (name === "hover" ? 70 : 40)) return; last[name] = n;
    try {
      if (!init()) return;
      if (ac.state === "suspended") ac.resume();
      master.gain.value = clamp(settings.volume, 0, 1) * 0.9;
      BANK[name]();
    } catch {}
  }
  return { play };
})();
const sfx = (n) => Sound.play(n);
// unlock audio on the first interaction
addEventListener("pointerdown", () => Sound.play("__unlock"), { once: true, capture: true });
// global click + hover sounds (specific controls play their own sounds)
document.addEventListener("click", (e) => {
  const t = e.target.closest && e.target.closest("button, .chip, .swatch, .toggle, .br-tab");
  if (!t || t.closest(".win-ctl, .app-tile, .dock-item, .boot-start, .boot-skip, #ctx, .br-newtab, .br-tab .c")) return;
  sfx("click");
}, true);
let hoverEl = null;
document.addEventListener("mouseover", (e) => {
  const t = e.target.closest && e.target.closest(".app-tile, .dock-item");
  if (t && t !== hoverEl) sfx("hover");
  hoverEl = t || null;
});

/* ═════════ orbit icon (planet + tilted ring + moon that passes behind & in front) ═════════ */
const orbitIcons = [];
let orbitUid = 0;
function orbitIcon(size = 64, { bg = false, phase = Math.random() * Math.PI * 2 } = {}) {
  const id = "oi" + orbitUid++;
  const wrap = el("span", { class: "orbit-icon" });
  wrap.style.width = wrap.style.height = size + "px";
  const TILT = -22;
  wrap.innerHTML = `
  <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="${id}bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1a1e55"/><stop offset="1" stop-color="#05060f"/></linearGradient>
      <radialGradient id="${id}p" cx="34%" cy="28%" r="85%"><stop offset="0" stop-color="#c4d0ff"/><stop offset=".38" stop-color="#7d70ff"/><stop offset=".78" stop-color="#2a1d8f"/><stop offset="1" stop-color="#120a4a"/></radialGradient>
      <radialGradient id="${id}t" cx="30%" cy="26%" r="90%"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#02000f" stop-opacity=".7"/></radialGradient>
      <radialGradient id="${id}m" cx="34%" cy="30%" r="80%"><stop offset="0" stop-color="#ffffff"/><stop offset=".6" stop-color="#cfd5ea"/><stop offset="1" stop-color="#7f88a8"/></radialGradient>
      <linearGradient id="${id}r" x1="8" y1="0" x2="92" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#35d6ff"/><stop offset=".5" stop-color="#a99bff"/><stop offset="1" stop-color="#ff7ad0"/></linearGradient>
      <clipPath id="${id}c"><circle cx="50" cy="50" r="21"/></clipPath>
      <filter id="${id}g" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="2.2"/></filter>
    </defs>
    ${bg ? `<rect x="2" y="2" width="96" height="96" rx="24" fill="url(#${id}bg)"/>
    <circle cx="18" cy="22" r=".9" fill="#fff" opacity=".9"/><circle cx="82" cy="16" r=".7" fill="#fff" opacity=".7"/><circle cx="12" cy="76" r=".7" fill="#fff" opacity=".6"/><circle cx="88" cy="82" r="1" fill="#fff" opacity=".8"/><circle cx="70" cy="90" r=".6" fill="#fff" opacity=".6"/>` : ""}
    <g transform="rotate(${TILT} 50 50)">
      <path d="M8 50A42 14 0 0 1 92 50" fill="none" stroke="url(#${id}r)" stroke-width="5" opacity=".35" filter="url(#${id}g)"/>
      <path d="M8 50A42 14 0 0 1 92 50" fill="none" stroke="url(#${id}r)" stroke-width="2.4" stroke-linecap="round" opacity=".75"/>
      <circle class="mB" cx="50" cy="50" r="4" fill="url(#${id}m)"/>
    </g>
    <circle cx="50" cy="50" r="21" fill="url(#${id}p)"/>
    <g clip-path="url(#${id}c)">
      <ellipse cx="50" cy="42" rx="26" ry="3" fill="#fff" opacity=".07" transform="rotate(${TILT} 50 50)"/>
      <ellipse cx="50" cy="55" rx="26" ry="2.2" fill="#fff" opacity=".06" transform="rotate(${TILT} 50 50)"/>
      <ellipse cx="50" cy="61" rx="26" ry="1.6" fill="#1a0f66" opacity=".25" transform="rotate(${TILT} 50 50)"/>
      <circle cx="50" cy="50" r="21" fill="url(#${id}t)"/>
      <g transform="rotate(${TILT} 50 50)"><path d="M8 52.6A42 14 0 0 0 92 52.6" fill="none" stroke="#000" stroke-width="3.2" opacity=".32"/></g>
    </g>
    <circle cx="50" cy="50" r="20.7" fill="none" stroke="#fff" stroke-opacity=".16" stroke-width=".7"/>
    <g transform="rotate(${TILT} 50 50)">
      <path d="M8 50A42 14 0 0 0 92 50" fill="none" stroke="url(#${id}r)" stroke-width="5" opacity=".35" filter="url(#${id}g)"/>
      <path d="M8 50A42 14 0 0 0 92 50" fill="none" stroke="url(#${id}r)" stroke-width="2.6" stroke-linecap="round"/>
      <circle class="mF" cx="50" cy="50" r="5" fill="url(#${id}m)"/>
    </g>
  </svg>`;
  const mB = $(".mB", wrap), mF = $(".mF", wrap);
  const entry = { wrap, mB, mF, phase, angle: 0, speed: 1, force: false };
  wrap.__orbit = entry; orbitIcons.push(entry);
  return wrap;
}
let lastT = performance.now();
function tickOrbit(t) {
  const dt = Math.min(0.05, (t - lastT) / 1000);
  lastT = t;
  for (let i = orbitIcons.length - 1; i >= 0; i--) {
    const o = orbitIcons[i];
    if (!o.wrap.isConnected) { if (o.wrap.__seen) orbitIcons.splice(i, 1); continue; }
    o.wrap.__seen = true;
    if (settings.motion || o.force) o.angle += dt * 0.95 * o.speed;
    const a = o.angle + o.phase, s = Math.sin(a);
    const x = 50 + 42 * Math.cos(a), y = 50 + 14 * s;
    const front = s >= 0;
    const m = front ? o.mF : o.mB, h = front ? o.mB : o.mF;
    m.setAttribute("cx", x.toFixed(2)); m.setAttribute("cy", y.toFixed(2));
    m.setAttribute("r", (4.1 + 1.5 * s).toFixed(2));
    m.style.opacity = front ? 1 : 0.92 + 0.08 * (1 + s);
    m.style.display = ""; h.style.display = "none";
  }
  requestAnimationFrame(tickOrbit);
}
requestAnimationFrame(tickOrbit);

/* ═════════ space background ═════════ */
(function space() {
  const cv = $("#space"), ctx = cv.getContext("2d");
  let W = 0, H = 0, DPR = 1, stars = [], shooters = [], nebula = null, mx = 0, my = 0, tx = 0, ty = 0;
  function mkNebula() {
    nebula = document.createElement("canvas");
    nebula.width = W; nebula.height = H;
    const n = nebula.getContext("2d");
    n.fillStyle = "#04050d"; n.fillRect(0, 0, W, H);
    const blobs = [
      [0.2, 0.25, 0.6, "124,108,255", 0.34], [0.8, 0.3, 0.5, "53,214,255", 0.2], [0.55, 0.85, 0.65, "255,95,162", 0.2],
      [0.1, 0.9, 0.45, "70,60,200", 0.28], [0.9, 0.85, 0.4, "90,70,255", 0.22],
    ];
    n.globalCompositeOperation = "lighter";
    for (const [bx, by, br, c, a] of blobs) {
      const r = br * Math.max(W, H) * 0.7, g = n.createRadialGradient(bx * W, by * H, 0, bx * W, by * H, r);
      g.addColorStop(0, `rgba(${c},${a})`); g.addColorStop(0.45, `rgba(${c},${a * 0.35})`); g.addColorStop(1, `rgba(${c},0)`);
      n.fillStyle = g; n.fillRect(0, 0, W, H);
    }
  }
  function resize() {
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = innerWidth; H = innerHeight;
    cv.width = W * DPR; cv.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const count = Math.round((W * H) / 3800);
    stars = Array.from({ length: count }, () => {
      const layer = Math.random();
      return { x: Math.random() * W, y: Math.random() * H, z: layer < 0.6 ? 0.25 : layer < 0.9 ? 0.6 : 1,
        r: Math.random() * 1.1 + 0.25, tw: Math.random() * 6.28, sp: 0.4 + Math.random() * 1.4,
        hue: Math.random() < 0.18 ? "190,215,255" : Math.random() < 0.1 ? "255,200,230" : "255,255,255" };
    });
    mkNebula();
  }
  addEventListener("resize", resize);
  addEventListener("mousemove", (e) => { tx = (e.clientX / W - 0.5); ty = (e.clientY / H - 0.5); });
  resize();
  let last = performance.now(), drift = 0, nextShoot = 2 + Math.random() * 4;
  function frame(t) {
    const dt = Math.min(0.05, (t - last) / 1000); last = t;
    const mo = settings.motion;
    if (mo) { drift += dt; mx += (tx - mx) * 0.04; my += (ty - my) * 0.04; }
    ctx.globalCompositeOperation = "source-over";
    ctx.drawImage(nebula, -20 + mx * -18, -20 + my * -18 - 0, W + 40, H + 40);
    // slow rotating glow
    const gx = W * (0.5 + Math.sin(drift * 0.05) * 0.18), gy = H * (0.45 + Math.cos(drift * 0.04) * 0.14);
    const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, Math.max(W, H) * 0.5);
    g.addColorStop(0, "rgba(120,100,255,0.10)"); g.addColorStop(1, "rgba(120,100,255,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    for (const s of stars) {
      if (mo) { s.y += dt * 2.2 * s.z; s.x += dt * 1.2 * s.z; if (s.y > H + 2) s.y = -2; if (s.x > W + 2) s.x = -2; s.tw += dt * s.sp; }
      const a = 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(s.tw));
      const px = s.x + mx * 26 * s.z, py = s.y + my * 26 * s.z;
      ctx.beginPath(); ctx.arc(px, py, s.r * (0.6 + s.z * 0.6), 0, 6.283);
      ctx.fillStyle = `rgba(${s.hue},${(a * (0.4 + s.z * 0.6)).toFixed(3)})`; ctx.fill();
      if (s.z === 1 && s.r > 1) { ctx.fillStyle = `rgba(${s.hue},${(a * 0.12).toFixed(3)})`; ctx.beginPath(); ctx.arc(px, py, s.r * 3.2, 0, 6.283); ctx.fill(); }
    }
    if (mo) {
      nextShoot -= dt;
      if (nextShoot <= 0) {
        nextShoot = 4 + Math.random() * 7;
        const a = Math.PI * (0.18 + Math.random() * 0.14);
        shooters.push({ x: Math.random() * W * 0.8, y: Math.random() * H * 0.4, vx: Math.cos(a) * 780, vy: Math.sin(a) * 780, life: 0, max: 0.9 });
      }
    }
    for (let i = shooters.length - 1; i >= 0; i--) {
      const s = shooters[i]; s.life += dt; s.x += s.vx * dt; s.y += s.vy * dt;
      const k = 1 - s.life / s.max; if (k <= 0) { shooters.splice(i, 1); continue; }
      const tl = 130, l = Math.hypot(s.vx, s.vy);
      const lg = ctx.createLinearGradient(s.x, s.y, s.x - (s.vx / l) * tl, s.y - (s.vy / l) * tl);
      lg.addColorStop(0, `rgba(255,255,255,${k})`); lg.addColorStop(1, "rgba(160,170,255,0)");
      ctx.strokeStyle = lg; ctx.lineWidth = 1.6; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x - (s.vx / l) * tl, s.y - (s.vy / l) * tl); ctx.stroke();
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();

/* ═════════ custom cursor ═════════ */
(function cursor() {
  if (matchMedia("(pointer: coarse)").matches) return;
  const dot = $("#cursor-dot"), ring = $("#cursor-ring");
  let x = innerWidth / 2, y = innerHeight / 2, rx = x, ry = y;
  addEventListener("mousemove", (e) => {
    x = e.clientX; y = e.clientY; document.body.classList.add("cursor-on");
    const t = e.target;
    document.body.classList.toggle("cursor-hover", !!(t.closest && t.closest("button, a, input, select, label, .app-tile, .br-tab, .win-bar, [data-hover]")));
  });
  document.addEventListener("mouseout", (e) => { if (!e.relatedTarget) document.body.classList.remove("cursor-on"); });
  document.addEventListener("mouseover", (e) => { if (e.target.tagName === "IFRAME") document.body.classList.remove("cursor-on"); });
  addEventListener("mousedown", () => document.body.classList.add("cursor-down"));
  addEventListener("mouseup", () => document.body.classList.remove("cursor-down"));
  (function loop() {
    rx += (x - rx) * 0.2; ry += (y - ry) * 0.2;
    dot.style.transform = `translate(${x}px,${y}px)`;
    ring.style.transform = `translate(${rx}px,${ry}px)`;
    requestAnimationFrame(loop);
  })();
})();

/* ═════════ toast ═════════ */
let toastT;
function toast(msg, kind) {
  if (kind) sfx(kind);
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 3200);
}

/* ═════════ clock & battery ═════════ */
function tickClock() {
  const d = new Date();
  const hm = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  $("#clock").textContent = hm;
  $("#clock").title = d.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric", year: "numeric" });
  $("#hero-time").textContent = hm.replace(/\s?[AP]M/i, "");
  $("#hero-date").textContent = d.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
}
tickClock(); setInterval(tickClock, 1000);

(function battery() {
  const pct = $("#batt-pct"), fill = $("#batt-fill"), box = $("#batt"), ico = $("#batt-ico");
  function paint(b) {
    const p = Math.round(b.level * 100);
    pct.textContent = p + "%"; fill.style.width = Math.max(6, p) + "%";
    ico.classList.toggle("low", p <= 20 && !b.charging);
    box.classList.toggle("charging", !!b.charging);
    box.title = b.charging ? "Charging" : "On battery";
  }
  if (navigator.getBattery) {
    navigator.getBattery().then((b) => {
      paint(b); ["levelchange", "chargingchange"].forEach((e) => b.addEventListener(e, () => paint(b)));
    }).catch(() => {});
  } else { box.title = "Battery info isn't available in this browser"; }
})();

/* ═════════ proxy (Ultraviolet + Wisp + Epoxy) ═════════ */
const Proxy = {
  ready: null, ok: null, error: "",
  init() {
    if (this.ready) return this.ready;
    this.ready = (async () => {
      if (!("serviceWorker" in navigator)) throw new Error("Service workers aren't available here. Open ORBIT over https:// or on localhost.");
      if (typeof __uv$config === "undefined") throw new Error("Proxy scripts failed to load. Is the server running?");
      const reg = await navigator.serviceWorker.register("/sw.js", { scope: __uv$config.prefix });
      if (!reg.active) {
        const sw = reg.installing || reg.waiting;
        if (sw) await new Promise((res) => { if (sw.state === "activated") return res(); sw.addEventListener("statechange", () => sw.state === "activated" && res()); });
      }
      const conn = new BareMux.BareMuxConnection("/baremux/worker.js");
      const wisp = (location.protocol === "https:" ? "wss" : "ws") + "://" + location.host + "/wisp/";
      await conn.setTransport("/epoxy/index.mjs", [{ wisp }]);
      this.ok = true;
    })().catch((e) => { this.ok = false; this.error = e.message || String(e); this.ready = null; throw e; });
    return this.ready;
  },
  url(u) { return __uv$config.prefix + __uv$config.encodeUrl(u); },
  decode(href) {
    try {
      const L = new URL(href, location.href);
      if (!L.pathname.startsWith(__uv$config.prefix)) return null;
      return __uv$config.decodeUrl(L.href.slice(L.origin.length + __uv$config.prefix.length));
    } catch { return null; }
  },
};
function normalizeInput(v) {
  v = (v || "").trim();
  if (!v) return "";
  if (/^https?:\/\//i.test(v)) return v;
  if (/^[^\s]+\.[a-z]{2,}([/:?#].*)?$/i.test(v) || /^localhost(:\d+)?/i.test(v)) return "https://" + v;
  return settings.engine.replace("%s", encodeURIComponent(v));
}
const favicon = (url) => { try { return "https://www.google.com/s2/favicons?sz=64&domain=" + new URL(url).hostname; } catch { return ""; } };

/* ═════════ apps ═════════ */
const SYSTEM_APP = { id: "browse", name: "Orbit Browse", system: true };
let userApps = store.get("apps", []);
const HOME_CAP = 10; // slots on the home page (apps + the + tile)
const allApps = () => [SYSTEM_APP, ...userApps];
const saveApps = () => store.set("apps", userApps);
const hue = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };

function appIcon(app, cls = "") {
  const box = el("div", { class: "app-ico " + (app.system ? "sys " : "") + cls });
  if (app.system) { box.append(orbitIcon(68)); box.style.background = "none"; box.style.border = "0"; return box; }
  const letter = () => { box.innerHTML = ""; const l = el("div", { class: "letter" }, (app.name || "?")[0].toUpperCase()); l.style.background = `linear-gradient(135deg,hsl(${hue(app.name)} 70% 55%),hsl(${(hue(app.name) + 50) % 360} 70% 40%))`; box.append(l); };
  const src = app.icon || favicon(app.url);
  if (!src) { letter(); return box; }
  const img = el("img", { src, alt: "", draggable: "false" });
  img.addEventListener("error", letter);
  img.addEventListener("load", () => { if (img.naturalWidth <= 16 && !app.icon) letter(); });
  box.append(img);
  return box;
}
function appTile(app, delay = 0) {
  const t = el("button", { class: "app-tile", title: app.name, "data-id": app.id });
  t.style.animationDelay = delay + "ms";
  t.append(appIcon(app), el("span", { class: "app-name" }, app.name));
  t.addEventListener("click", () => { closeAllApps(); openApp(app); });
  t.addEventListener("contextmenu", (e) => { e.preventDefault(); showCtx(e.clientX, e.clientY, app); });
  return t;
}
function addTile(delay = 0) {
  const t = el("button", { class: "app-tile", title: "Add an app" });
  t.style.animationDelay = delay + "ms";
  t.append(el("div", { class: "app-ico add", html: I.plus }), el("span", { class: "app-name" }, "Add app"));
  t.addEventListener("click", () => openAppModal());
  return t;
}
function renderApps() {
  const apps = allApps();
  const home = $("#home-grid"); home.innerHTML = "";
  apps.slice(0, HOME_CAP).forEach((a, i) => home.append(appTile(a, i * 40)));
  if (apps.length < HOME_CAP) home.append(addTile(apps.length * 40));
  renderAll();
  renderDock();
}
function renderAll() {
  const q = ($("#aa-input").value || "").trim().toLowerCase();
  const g = $("#all-grid"); g.innerHTML = "";
  const list = allApps().filter((a) => !q || a.name.toLowerCase().includes(q));
  list.forEach((a, i) => g.append(appTile(a, i * 25)));
  if (!q) g.append(addTile(list.length * 25));
}
function openAllApps() {
  $("#aa-input").value = ""; renderAll();
  if (!allAppsOpen()) sfx("panel");
  $("#allapps").classList.add("open");
  setTimeout(() => $("#aa-input").focus(), 350);
  renderDock();
}
function closeAllApps() { if (allAppsOpen()) sfx("panelClose"); $("#allapps").classList.remove("open"); renderDock(); }
const allAppsOpen = () => $("#allapps").classList.contains("open");
$("#allapps").addEventListener("mousedown", (e) => { if (e.target === $("#allapps") || e.target.classList.contains("aa-wrap")) closeAllApps(); });
$("#aa-input").addEventListener("input", renderAll);

/* context menu */
function showCtx(x, y, app) {
  const c = $("#ctx"); c.innerHTML = "";
  c.append(el("button", { onclick: () => { hideCtx(); closeAllApps(); openApp(app); } }, "Open"));
  if (!app.system) {
    c.append(el("button", { onclick: () => { hideCtx(); openAppModal(app); } }, "Edit"));
    c.append(el("button", { class: "danger", onclick: () => { hideCtx(); sfx("remove"); userApps = userApps.filter((a) => a.id !== app.id); saveApps(); const w = wins.get("app:" + app.id); if (w) w.close(); renderApps(); toast(`${app.name} removed`); } }, "Remove"));
  }
  c.classList.add("open"); sfx("menu");
  c.style.left = Math.min(x, innerWidth - 190) + "px"; c.style.top = Math.min(y, innerHeight - 140) + "px";
}
function hideCtx() { $("#ctx").classList.remove("open"); }
addEventListener("mousedown", (e) => { if (!e.target.closest("#ctx")) hideCtx(); });

/* add / edit modal */
const AM = { editing: null, icon: "" };
const QUICK = [["YouTube", "youtube.com"], ["Google", "google.com"], ["Wikipedia", "wikipedia.org"], ["Reddit", "reddit.com"], ["Spotify", "open.spotify.com"], ["Khan Academy", "khanacademy.org"]];
$("#am-chips").append(...QUICK.map(([n, u]) => el("button", { type: "button", class: "chip", onclick: () => { $("#am-name").value = n; $("#am-url").value = u; updatePreview(); } }, n)));
function amPreviewApp() {
  const url = normalizeAppUrl($("#am-url").value);
  return { name: $("#am-name").value.trim() || (url ? new URL(url).hostname.replace(/^www\./, "") : "?"), url, icon: AM.icon };
}
function normalizeAppUrl(v) {
  v = (v || "").trim(); if (!v) return "";
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(v)) v = "https://" + v;
  try { const u = new URL(v); if (!/^https?:$/.test(u.protocol) || !u.hostname.includes(".") && u.hostname !== "localhost") return ""; return u.href; } catch { return ""; }
}
function updatePreview() {
  const p = $("#am-preview"); p.innerHTML = "";
  const a = amPreviewApp();
  if (!a.url && !a.icon) { p.replaceWith(el("div", { class: "app-ico add", id: "am-preview", html: I.plus })); return; }
  p.replaceWith(Object.assign(appIcon(a), { id: "am-preview" }));
}
function openAppModal(app = null) {
  AM.editing = app; AM.icon = app ? app.icon || "" : "";
  $("#am-title").textContent = app ? "Edit app" : "Add an app";
  $("#am-save").textContent = app ? "Save" : "Add app";
  $("#am-url").value = app ? app.url : ""; $("#am-name").value = app ? app.name : "";
  $("#am-chips-field").style.display = app ? "none" : ""; $("#am-err").textContent = "";
  updatePreview();
  $("#app-modal").classList.add("open");
  setTimeout(() => $("#am-url").focus(), 300);
}
const closeAppModal = () => $("#app-modal").classList.remove("open");
$("#am-cancel").addEventListener("click", closeAppModal);
$("#app-modal").addEventListener("mousedown", (e) => { if (e.target.id === "app-modal") closeAppModal(); });
$("#am-url").addEventListener("input", updatePreview);
$("#am-name").addEventListener("input", updatePreview);
$("#am-pick").addEventListener("click", () => $("#am-file").click());
$("#am-clear").addEventListener("click", () => { AM.icon = ""; $("#am-file").value = ""; updatePreview(); });
$("#am-file").addEventListener("change", (e) => {
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas"), S = 128; c.width = c.height = S;
      const x = c.getContext("2d"), m = Math.min(img.width, img.height);
      x.drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, S, S);
      AM.icon = c.toDataURL("image/png"); updatePreview();
    };
    img.onerror = () => { $("#am-err").textContent = "That image couldn't be read."; };
    img.src = r.result;
  };
  r.readAsDataURL(f);
});
$("#app-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const url = normalizeAppUrl($("#am-url").value);
  if (!url) { $("#am-err").textContent = "Enter a valid link, like example.com"; return; }
  const name = $("#am-name").value.trim() || new URL(url).hostname.replace(/^www\./, "");
  if (AM.editing) { Object.assign(AM.editing, { name, url, icon: AM.icon }); sfx("add"); toast("Saved"); }
  else { userApps.push({ id: uid(), name, url, icon: AM.icon }); sfx("add"); toast(`${name} added`); }
  saveApps(); closeAppModal(); renderApps();
});

/* ═════════ window manager ═════════ */
const wins = new Map();
let zTop = 10, cascade = 0;
function openWindow({ key, title, iconNode, w = 0.8, h = 0.82, minW = 420, minH = 300, build, onClose }) {
  if (key && wins.has(key)) { wins.get(key).focus(); return wins.get(key); }
  const desk = $("#desktop"), dw = desk.clientWidth, dh = desk.clientHeight;
  const W = clamp(Math.round(dw * w), Math.min(minW, dw), dw), H = clamp(Math.round(dh * h), Math.min(minH, dh), dh);
  const off = (cascade++ % 6) * 28;
  const win = el("div", { class: "win" });
  win.style.cssText = `width:${W}px;height:${H}px;left:${clamp((dw - W) / 2 + off - 56, 0, dw - W)}px;top:${clamp((dh - H) / 2 + off - 40, 0, dh - H)}px;z-index:${++zTop}`;
  const titleEl = el("span", {}, title);
  const mini = el("div", { class: "mini" }); if (iconNode) mini.append(iconNode);
  const fsBtn = el("button", { class: "fs", title: "Full screen", html: I.full, onclick: (e) => { e.stopPropagation(); api.toggleFull(); } });
  const bar = el("div", { class: "win-bar" }, [
    el("div", { class: "win-title" }, [mini, titleEl]),
    el("div", { class: "win-ctl" }, [
      fsBtn,
      el("button", { title: "Minimize", html: I.min, onclick: (e) => { e.stopPropagation(); api.minimize(); } }),
      el("button", { title: "Maximize", html: I.max, onclick: (e) => { e.stopPropagation(); api.toggleMax(); } }),
      el("button", { class: "x", title: "Close", html: I.close, onclick: (e) => { e.stopPropagation(); api.close(); } }),
    ]),
  ]);
  const body = el("div", { class: "win-body" });
  const rz = el("div", { class: "win-resize" }); rz.style.cursor = "nwse-resize";
  win.append(bar, body, rz);
  $("#windows").append(win);

  const api = {
    key, el: win, body, title,
    setTitle(t) { api.title = t; titleEl.textContent = t; renderDock(); },
    focus() { api.restore(); win.style.zIndex = ++zTop; $$(".win").forEach((x) => x.classList.toggle("focused", x === win)); api.focused = true; renderDock(); },
    minimize() { if (api.full) api.exitFull(true); win.classList.add("min"); api.minimized = true; sfx("minimize"); renderDock(); },
    restore() { if (api.minimized) { win.classList.remove("min"); api.minimized = false; sfx("restore"); } },
    full: false,
    toggleFull() { api.full ? api.exitFull() : api.enterFull(); },
    enterFull() {
      if (api.full) return;
      api.focus(); if (api.maxed) api.toggleMax();
      for (const w of wins.values()) if (w !== api && w.full) w.exitFull(true);
      win.classList.add("full"); api.full = true; document.body.classList.add("has-full");
      fsBtn.innerHTML = I.unfull; fsBtn.title = "Exit full screen"; sfx("fullscreen");
      const de = document.documentElement;
      if (!document.fullscreenElement && de.requestFullscreen) de.requestFullscreen().catch(() => {});
    },
    exitFull(quiet) {
      if (!api.full) return;
      win.classList.remove("full"); api.full = false; document.body.classList.remove("has-full");
      fsBtn.innerHTML = I.full; fsBtn.title = "Full screen"; if (!quiet) sfx("exitfull");
      if (!quiet && document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(() => {});
    },
    toggleMax() {
      sfx("maximize");
      if (!api.maxed) { api.prev = { l: win.style.left, t: win.style.top, w: win.style.width, h: win.style.height }; win.style.left = win.style.top = "0px"; win.style.width = "100%"; win.style.height = "100%"; win.classList.add("max"); api.maxed = true; }
      else { Object.assign(win.style, { left: api.prev.l, top: api.prev.t, width: api.prev.w, height: api.prev.h }); win.classList.remove("max"); api.maxed = false; }
    },
    close() {
      if (api.full) api.exitFull(true);
      sfx("close");
      if (onClose) onClose();
      win.classList.add("closing"); wins.delete(key || api.id);
      setTimeout(() => win.remove(), 320); renderDock();
    },
    icon: iconNode,
  };
  api.id = key || "w" + uid();
  wins.set(api.id, api);

  // dragging
  bar.addEventListener("pointerdown", (e) => {
    if (e.target.closest(".win-ctl")) return;
    api.focus();
    if (api.maxed || api.full) return;
    const sx = e.clientX, sy = e.clientY, ox = win.offsetLeft, oy = win.offsetTop;
    document.body.classList.add("dragging"); win.classList.add("dragging"); bar.setPointerCapture(e.pointerId);
    const mv = (m) => {
      win.style.left = clamp(ox + m.clientX - sx, -W + 120, desk.clientWidth - 120) + "px";
      win.style.top = clamp(oy + m.clientY - sy, 0, desk.clientHeight - 42) + "px";
    };
    const up = () => { bar.removeEventListener("pointermove", mv); bar.removeEventListener("pointerup", up); document.body.classList.remove("dragging"); win.classList.remove("dragging"); };
    bar.addEventListener("pointermove", mv); bar.addEventListener("pointerup", up);
  });
  bar.addEventListener("dblclick", (e) => { if (!e.target.closest(".win-ctl") && !api.full) api.toggleMax(); });
  // resizing
  rz.addEventListener("pointerdown", (e) => {
    if (api.maxed || api.full) return; e.preventDefault(); api.focus();
    const sx = e.clientX, sy = e.clientY, ow = win.offsetWidth, oh = win.offsetHeight;
    document.body.classList.add("dragging"); win.classList.add("resizing"); rz.setPointerCapture(e.pointerId);
    const mv = (m) => { win.style.width = Math.max(minW, ow + m.clientX - sx) + "px"; win.style.height = Math.max(minH, oh + m.clientY - sy) + "px"; };
    const up = () => { rz.removeEventListener("pointermove", mv); rz.removeEventListener("pointerup", up); document.body.classList.remove("dragging"); win.classList.remove("resizing"); };
    rz.addEventListener("pointermove", mv); rz.addEventListener("pointerup", up);
  });
  win.addEventListener("pointerdown", () => { if (!win.classList.contains("focused")) api.focus(); }, true);

  build(api);
  api.focus();
  sfx("open");
  return api;
}

/* ═════════ dock ═════════ */
function dockItem({ icon, tip, onclick, running, minimized }) {
  const b = el("button", { class: "dock-item" + (running ? " running" : "") + (minimized ? " minimized" : ""), onclick }, [icon, el("span", { class: "dock-tip" }, tip)]);
  return b;
}
function renderDock() {
  const d = $("#dock"); d.innerHTML = "";
  const br = [...wins.values()].some((w) => w.key === "browse");
  d.append(dockItem({ icon: appIcon(SYSTEM_APP), tip: "Orbit Browse", onclick: () => openApp(SYSTEM_APP), running: br, minimized: br && wins.get("browse").minimized }));
  d.append(dockItem({ icon: el("div", { class: "app-ico", html: I.grid }), tip: "View apps", onclick: () => (allAppsOpen() ? closeAllApps() : openAllApps()), running: allAppsOpen() }));
  const others = [...wins.values()].filter((w) => w.key !== "browse");
  if (others.length) d.append(el("div", { class: "dock-sep" }));
  for (const w of others) {
    let ic;
    if (w.appRef) ic = appIcon(w.appRef); else ic = el("div", { class: "app-ico", html: I.globe });
    d.append(dockItem({ icon: ic, tip: w.title, running: true, minimized: w.minimized,
      onclick: () => { if (!w.minimized && w.el.classList.contains("focused")) w.minimize(); else w.focus(); } }));
  }
}
const zone = $("#dock-zone");
let dockT;
const showDock = () => { clearTimeout(dockT); if (!zone.classList.contains("show")) sfx("dock"); zone.classList.add("show"); };
zone.addEventListener("mouseenter", showDock);
zone.addEventListener("mouseleave", () => { clearTimeout(dockT); dockT = setTimeout(() => zone.classList.remove("show"), 450); });
document.addEventListener("mouseleave", () => zone.classList.remove("show"));
// reveal when the pointer touches the bottom edge anywhere near the center
addEventListener("mousemove", (e) => {
  if (e.clientY > innerHeight - 10 && Math.abs(e.clientX - innerWidth / 2) < 260) showDock();
});

/* ═════════ browser ═════════ */
function openApp(app) {
  if (app.system) {
    const ex = wins.get("browse");
    if (ex) { if (!ex.minimized && ex.el.classList.contains("focused")) ex.minimize(); else ex.focus(); return; }
    openBrowser({ key: "browse", title: "Orbit Browse", iconNode: orbitIcon(18) });
  } else {
    const k = "app:" + app.id;
    if (wins.has(k)) return wins.get(k).focus();
    openBrowser({ key: k, title: app.name, iconNode: appIcon(app), appMode: true, startUrl: app.url, app });
  }
}
function openBrowser({ key, title, iconNode, appMode = false, startUrl = "", app = null }) {
  const win = openWindow({
    key, title, iconNode, w: 0.82, h: 0.84, minW: 460, minH: 340,
    build(api) { new Browser(api, { appMode, startUrl }); },
  });
  if (app) { win.appRef = app; renderDock(); }
  return win;
}

class Browser {
  constructor(win, { appMode, startUrl }) {
    this.win = win; this.appMode = appMode; this.startUrl = startUrl; this.tabs = []; this.active = null;
    const body = win.body;
    this.tabsEl = el("div", { class: "br-tabs" });
    this.newBtn = el("button", { class: "br-newtab", title: "New tab", html: I.plus, onclick: () => this.newTab() });
    this.back = el("button", { class: "br-btn", title: "Back", html: I.back, onclick: () => this.nav("back") });
    this.fwd = el("button", { class: "br-btn", title: "Forward", html: I.fwd, onclick: () => this.nav("forward") });
    this.rel = el("button", { class: "br-btn", title: "Reload", html: I.reload, onclick: () => this.reload() });
    this.homeBtn = el("button", { class: "br-btn", title: appMode ? "App home" : "New tab page", html: I.home, onclick: () => (this.appMode ? this.go(this.startUrl) : this.showNewtab(this.active)) });
    this.input = el("input", { type: "text", placeholder: "Search or enter address", spellcheck: "false", autocomplete: "off" });
    this.input.addEventListener("keydown", (e) => { if (e.key === "Enter") { this.go(this.input.value); this.input.blur(); } });
    this.input.addEventListener("focus", () => this.input.select());
    this.load = el("div", { class: "br-load" });
    const urlbox = el("div", { class: "br-url", html: I.lock }); urlbox.append(this.input);
    const bar = el("div", { class: "br-bar" }, [this.back, this.fwd, this.rel, this.homeBtn, urlbox, this.load]);
    this.views = el("div", { class: "br-views" });
    if (!appMode) body.append(this.tabsEl);
    body.append(bar, this.views);
    this.renderTabs();
    this.newTab(startUrl || "");
    this.poll = setInterval(() => { if (!win.el.isConnected) return clearInterval(this.poll); this.sync(this.active); }, 1000);
  }
  newTab(url = "") {
    const tab = { id: uid(), title: "New tab", url: "", view: null, iframe: null, fav: "" };
    tab.view = el("div", { class: "br-view" });
    this.views.append(tab.view);
    this.tabs.push(tab);
    if (this.tabs.length > 1) sfx("tab");
    this.activate(tab);
    if (url) this.go(url, tab); else this.showNewtab(tab);
    return tab;
  }
  activate(tab) {
    this.active = tab;
    for (const t of this.tabs) t.view.classList.toggle("active", t === tab);
    this.renderTabs(); this.updateBar();
  }
  closeTab(tab) {
    const i = this.tabs.indexOf(tab); if (i < 0) return;
    if (this.tabs.length === 1) { this.win.close(); return; }
    sfx("tabClose"); this.tabs.splice(i, 1); tab.view.remove();
    if (this.active === tab) this.activate(this.tabs[Math.max(0, i - 1)]); else this.renderTabs();
  }
  renderTabs() {
    this.tabsEl.innerHTML = "";
    for (const t of this.tabs) {
      const fav = el("img", { src: t.fav || "", alt: "" });
      fav.addEventListener("error", () => { fav.style.visibility = "hidden"; });
      if (!t.fav) fav.style.visibility = "hidden";
      const node = el("div", { class: "br-tab" + (t === this.active ? " active" : ""), onclick: () => this.activate(t) }, [
        fav, el("span", { class: "t" }, t.title),
        el("button", { class: "c", html: I.close, title: "Close tab", onclick: (e) => { e.stopPropagation(); this.closeTab(t); } }),
      ]);
      this.tabsEl.append(node);
    }
    this.tabsEl.append(this.newBtn);
  }
  updateBar() {
    const t = this.active; if (!t) return;
    if (document.activeElement !== this.input) this.input.value = t.url || "";
    this.homeBtn.style.opacity = t.iframe ? 1 : 0.4;
  }
  showNewtab(tab) {
    if (!tab) return;
    tab.iframe = null; tab.url = ""; tab.title = "New tab"; tab.fav = "";
    tab.view.className = "br-view newtab" + (tab === this.active ? " active" : "");
    tab.view.innerHTML = "";
    const search = el("form", { class: "nt-search", html: I.search });
    const inp = el("input", { type: "text", placeholder: "Search the web or type a link", autocomplete: "off", spellcheck: "false" });
    search.append(inp);
    search.addEventListener("submit", (e) => { e.preventDefault(); if (inp.value.trim()) this.go(inp.value, tab); });
    const links = el("div", { class: "nt-links" });
    userApps.slice(0, 8).forEach((a) => { const t = el("button", { class: "app-tile", title: a.name, onclick: () => this.go(a.url, tab) }); t.append(appIcon(a), el("span", { class: "app-name" }, a.name)); links.append(t); });
    tab.view.append(el("div", { class: "nt-logo" }, orbitIcon(84, { bg: true })), el("div", { class: "nt-title" }, "ORBIT"), search, links);
    this.renderTabs(); this.updateBar();
    if (tab === this.active) setTimeout(() => inp.focus(), 60);
  }
  async go(input, tab = this.active) {
    const url = normalizeInput(input); if (!url || !tab) return;
    tab.url = url; tab.title = new URL(url).hostname.replace(/^www\./, ""); tab.fav = favicon(url);
    tab.view.className = "br-view" + (tab === this.active ? " active" : ""); tab.view.innerHTML = "";
    this.renderTabs(); this.updateBar(); this.loading(true);
    try {
      await Proxy.init();
    } catch (err) {
      this.loading(false); sfx("error");
      tab.iframe = null;
      tab.view.append(el("div", { class: "err-card" }, [
        el("h3", {}, "The proxy isn't ready"), el("p", {}, Proxy.error || String(err.message || err)),
        el("button", { class: "btn primary", onclick: () => this.go(url, tab) }, "Try again"),
      ]));
      return;
    }
    const f = el("iframe", { allow: "fullscreen; autoplay; clipboard-write; encrypted-media; picture-in-picture", referrerpolicy: "no-referrer" });
    f.addEventListener("load", () => { this.loading(false); this.sync(tab); sfx("loaded"); });
    tab.iframe = f; tab.view.append(f);
    f.src = Proxy.url(url);
    this.updateBar();
  }
  sync(tab) {
    if (!tab || !tab.iframe) return;
    try {
      const w = tab.iframe.contentWindow;
      let changed = false;
      const real = Proxy.decode(w.location.href);
      if (real && real !== tab.url) { tab.url = real; tab.fav = favicon(real); changed = true; }
      const t = w.document.title;
      const nt = t || (tab.url ? new URL(tab.url).hostname.replace(/^www\./, "") : "");
      if (nt && nt !== tab.title) { tab.title = nt; changed = true; }
      if (changed) { this.renderTabs(); if (tab === this.active) this.updateBar(); }
    } catch {}
  }
  nav(dir) { const t = this.active; if (!t || !t.iframe) return; try { t.iframe.contentWindow.history[dir](); } catch {} }
  reload() { const t = this.active; if (!t) return; if (t.iframe) { this.loading(true); try { t.iframe.contentWindow.location.reload(); } catch { t.iframe.src = t.iframe.src; } } else if (t.url) this.go(t.url, t); }
  loading(on) {
    const l = this.load; l.className = "br-load";
    if (on) { void l.offsetWidth; l.classList.add("on"); } else { l.classList.add("done"); }
  }
}

/* ═════════ settings window ═════════ */
function openSettings() {
  openWindow({
    key: "settings", title: "Settings", iconNode: el("div", { html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:18px;height:18px"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/></svg>' }),
    w: 0.6, h: 0.7, minW: 480, minH: 360,
    build(api) {
      const wrap = el("div", { class: "set-wrap" }), nav = el("div", { class: "set-nav" }), main = el("div", { class: "set-main" });
      const pages = {
        Appearance() {
          const sw = el("div", { class: "swatches" });
          ["#7c6cff", "#35d6ff", "#ff5fa2", "#3ddc97", "#ffb347"].forEach((c) => {
            const s = el("button", { class: "swatch" + (settings.accent === c ? " on" : ""), title: c, onclick: () => { settings.accent = c; applySettings(); show("Appearance"); } });
            s.style.background = c; sw.append(s);
          });
          const tg = el("button", { class: "toggle" + (settings.motion ? " on" : ""), onclick: () => { settings.motion = !settings.motion; applySettings(); show("Appearance"); } });
          const ti = el("button", { class: "toggle" + (settings.intro ? " on" : ""), onclick: () => { settings.intro = !settings.intro; applySettings(); show("Appearance"); } });
          return [el("h3", {}, "Appearance"),
            el("div", { class: "set-row" }, [el("div", {}, ["Accent color", el("small", {}, "Used for highlights, buttons and the cursor glow")]), sw]),
            el("div", { class: "set-row" }, [el("div", {}, ["Boot intro", el("small", {}, "Play the startup animation and sound when ORBIT opens")]), ti]),
            el("div", { class: "set-row" }, [el("div", {}, ["Animated space", el("small", {}, "Turn off to freeze stars and the orbiting moon")]), tg])];
        },
        Browser() {
          const sel = el("select", { onchange: (e) => { settings.engine = e.target.value; applySettings(); toast("Search engine updated"); } });
          [["DuckDuckGo", "https://duckduckgo.com/?q=%s"], ["Bing", "https://www.bing.com/search?q=%s"], ["Brave Search", "https://search.brave.com/search?q=%s"], ["Google", "https://www.google.com/search?q=%s"]]
            .forEach(([n, v]) => sel.append(el("option", { value: v, ...(settings.engine === v ? { selected: "" } : {}) }, n)));
          const dot = el("span", { class: "status-dot" + (Proxy.ok === true ? " ok" : Proxy.ok === false ? " bad" : "") });
          const st = el("span", {}, Proxy.ok === true ? "Connected" : Proxy.ok === false ? "Error: " + Proxy.error : "Starts with your first page");
          const test = el("button", { class: "btn", onclick: async () => { test.textContent = "Connecting…"; try { await Proxy.init(); toast("Proxy connected", "notify"); } catch (e) { toast(e.message, "error"); } show("Browser"); } }, "Test connection");
          return [el("h3", {}, "Browser"),
            el("div", { class: "set-row" }, [el("div", {}, ["Search engine", el("small", {}, "Used when you type something that isn't a link")]), sel]),
            el("div", { class: "set-row" }, [el("div", {}, ["Proxy status", el("small", {}, [dot, st])]), test])];
        },
        Data() {
          return [el("h3", {}, "Data"),
            el("div", { class: "set-row" }, [el("div", {}, ["Remove all added apps", el("small", {}, "Orbit Browse stays")]), el("button", { class: "btn danger", onclick: () => { userApps = []; saveApps(); renderApps(); toast("Apps cleared"); } }, "Clear apps")]),
            el("div", { class: "set-row" }, [el("div", {}, ["Reset ORBIT", el("small", {}, "Clears apps and settings, then reloads")]), el("button", { class: "btn danger", onclick: () => { try { Object.keys(localStorage).filter((k) => k.startsWith("orbit.")).forEach((k) => localStorage.removeItem(k)); } catch {} location.reload(); } }, "Reset")])];
        },
        Sound() {
          const tg = el("button", { class: "toggle" + (settings.sfx ? " on" : ""), onclick: () => { settings.sfx = !settings.sfx; applySettings(); show("Sound"); if (settings.sfx) sfx("notify"); } });
          const vol = el("input", { type: "range", min: "0", max: "100", value: String(Math.round(settings.volume * 100)), class: "range" });
          vol.addEventListener("input", () => { settings.volume = vol.value / 100; });
          vol.addEventListener("change", () => { applySettings(); sfx("notify"); });
          return [el("h3", {}, "Sound"),
            el("div", { class: "set-row" }, [el("div", {}, ["System sounds", el("small", {}, "Clicks, windows, dock and notifications")]), tg]),
            el("div", { class: "set-row" }, [el("div", {}, ["Volume", el("small", {}, "Applies to system sounds, not the intro")]), vol])];
        },
        About() {
          return [el("div", { class: "about" }, [orbitIcon(96, { bg: true }), el("h3", {}, "ORBIT"), el("div", { style: "color:var(--muted);font-size:13px;line-height:1.6" }, "A tiny operating system in your browser.\nBrowsing is powered by Ultraviolet, Epoxy and Wisp.")])];
        },
      };
      function show(name) {
        $$("button", nav).forEach((b) => b.classList.toggle("active", b.textContent === name));
        main.innerHTML = ""; main.append(...pages[name]());
      }
      Object.keys(pages).forEach((n) => nav.append(el("button", { onclick: () => show(n) }, n)));
      wrap.append(nav, main); api.body.append(wrap); show("Appearance");
    },
  });
}
$("#settings-btn").addEventListener("click", openSettings);

/* ═════════ keyboard ═════════ */
addEventListener("keydown", (e) => {
  if (e.key === "Escape") { closeAppModal(); closeAllApps(); hideCtx(); for (const w of wins.values()) if (w.full) w.exitFull(); }
});
document.addEventListener("fullscreenchange", () => { if (!document.fullscreenElement) for (const w of wins.values()) if (w.full) w.exitFull(true); });
addEventListener("contextmenu", (e) => { if (!e.target.closest(".app-tile, input")) e.preventDefault(); });

/* ═════════ boot / intro (audio-reactive) ═════════ */
renderApps();
setTimeout(() => Proxy.init().catch(() => {}), 1500); // warm up the proxy in the background

(function intro() {
  const boot = $("#boot");
  if (!settings.intro) { boot.remove(); document.body.classList.remove("booting"); return; }

  const fx = $("#boot-fx"), ctx = fx.getContext("2d"), logoBox = $("#boot-logo"), nameEl = $("#boot-name"), fill = $("#boot-fill");
  const size = Math.round(Math.min(230, Math.min(innerWidth, innerHeight) * 0.4));
  const icon = orbitIcon(size, { phase: 0.4 });
  const ent = icon.__orbit; ent.force = true; ent.speed = 0.35;
  logoBox.append(icon);
  const letters = [..."ORBIT"].map((c) => el("span", {}, c));
  nameEl.append(...letters);

  const END = 11.3, FIRST_HIT = 1.98;
  const HITS = [[1.98, 1], [7.5, 0.7], [7.95, 1]];
  const hex = settings.accent.replace("#", "");
  const [AR, AG, AB] = [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const acc = (a) => `rgba(${AR},${AG},${AB},${a})`;

  // data + audio
  let env = null;
  fetch("/audio/intro.json").then((r) => r.json()).then((d) => (env = d)).catch(() => {});
  const audio = new Audio("/audio/intro.mp3"); audio.preload = "auto";
  const sample = (k, t) => {
    if (!env) return t > 1.9 && t < END ? 0.45 + 0.3 * Math.sin(t * 9) : 0;
    const x = Math.max(0, t) * env.fps, i = Math.floor(x), f = x - i, arr = env[k];
    if (i >= arr.length - 1) return 0;
    return arr[i] * (1 - f) + arr[i + 1] * f;
  };

  // canvas world
  let W = 0, H = 0, DPR = 1, maxR = 1;
  function size_() { DPR = Math.min(2, devicePixelRatio || 1); W = innerWidth; H = innerHeight; fx.width = W * DPR; fx.height = H * DPR; ctx.setTransform(DPR, 0, 0, DPR, 0, 0); maxR = Math.hypot(W, H) / 2; }
  size_(); addEventListener("resize", size_);
  const stars = Array.from({ length: 260 }, () => ({ a: Math.random() * 6.283, d: Math.random(), s: 0.4 + Math.random() * 0.9, b: 0.4 + Math.random() * 0.6 }));
  let shocks = [], parts = [], flash = 0, pulse = 0;

  let started = false, finished = false, t0 = 0, raf = 0, last = performance.now(), fired = new Set(), lastShock = -9;
  const sm = { rms: 0, low: 0, high: 0 };
  const now = () => (!audio.paused && audio.currentTime > 0 ? audio.currentTime : (performance.now() - t0) / 1000);

  function shock(str) { shocks.push({ r: 20, a: 0.85 * str + 0.15, v: maxR * (0.9 + str * 0.5), w: 1.5 + str * 3 }); lastShock = now(); }
  function burst(cx, cy, n) {
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = 140 + Math.random() * 520; parts.push({ x: cx, y: cy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 0, m: 0.8 + Math.random() * 1.1, r: 0.8 + Math.random() * 1.8 }); }
  }

  function frame(tm) {
    if (finished) return;
    const dt = Math.min(0.05, (tm - last) / 1000); last = tm;
    const t = started ? now() : -1;
    const run = started && t >= FIRST_HIT;
    // envelope with attack / release
    const sampleAt = started ? t : 0;
    for (const k of ["rms", "low", "high"]) { const v = started ? sample(k, sampleAt) : 0; sm[k] += (v - sm[k]) * (v > sm[k] ? 0.55 : 0.12); }

    const rect = logoBox.getBoundingClientRect(), cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;

    if (started) {
      for (const [ht, str] of HITS) if (t >= ht && !fired.has(ht)) { fired.add(ht); shock(str); pulse = Math.max(pulse, 0.16 * str); flash = Math.max(flash, 0.5 * str); if (str === 1) burst(cx, cy, 90); }
      if (t - lastShock > 0.3 && sample("low", t) > 0.5 && sample("low", t) - sample("low", t - 0.09) > 0.22) shock(0.45);
      if (t >= END) return finish();
    }
    pulse *= Math.exp(-dt * 4.5); flash *= Math.exp(-dt * 5);

    // logo
    const prep = started && t < FIRST_HIT ? Math.max(0, t) / FIRST_HIT : 0;
    const baseOp = !started ? 0.5 : run ? 1 : 0.28 + 0.22 * prep;
    const scale = !started ? 0.92 : run ? 1 + 0.09 * sm.low + pulse : 0.84 + 0.06 * prep;
    logoBox.style.opacity = baseOp;
    logoBox.style.transform = `scale(${scale.toFixed(4)})`;
    logoBox.style.filter = `drop-shadow(0 0 ${(18 + 100 * sm.rms).toFixed(0)}px ${acc((0.28 + 0.6 * sm.rms).toFixed(3))})`;
    ent.speed = !started ? 0.35 : run ? 0.7 + 10 * sm.rms : 0.5 + prep * 1.2;

    // wordmark & progress
    if (started) {
      letters.forEach((l, i) => l.classList.toggle("on", t >= 2.5 + i * 0.28));
      nameEl.style.textShadow = `0 0 ${(6 + 40 * sm.high).toFixed(0)}px ${acc((0.25 + 0.7 * sm.high).toFixed(3))}`;
      fill.style.width = (Math.min(1, t / END) * 100).toFixed(2) + "%";
    }

    // canvas
    ctx.clearRect(0, 0, W, H);
    const warp = !started ? 0.02 : run ? 0.05 + 2.2 * sm.rms : 0.03 + 0.2 * prep;
    for (const s of stars) {
      const pd = s.d; s.d += dt * (0.025 + warp * 0.55) * (0.25 + s.d) * s.s;
      if (s.d > 1) { s.d = Math.random() * 0.06; s.a = Math.random() * 6.283; }
      const r1 = pd * maxR, r2 = s.d * maxR, ca = Math.cos(s.a), sa = Math.sin(s.a);
      const alpha = Math.min(1, s.d * 2.4) * s.b;
      ctx.strokeStyle = `rgba(${200 + (s.b * 55) | 0},${210 + (s.b * 45) | 0},255,${alpha.toFixed(3)})`;
      ctx.lineWidth = 0.6 + s.d * 1.3; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(cx + ca * Math.min(r1, r2 - 0.5), cy + sa * Math.min(r1, r2 - 0.5)); ctx.lineTo(cx + ca * r2, cy + sa * r2); ctx.stroke();
    }
    // charging ring before first hit
    if (started && t < FIRST_HIT + 0.05 && prep > 0) {
      const rx = size * 0.42 * 0.86, ry = size * 0.14 * 0.86, p = Math.min(1, prep * 1.05);
      ctx.save(); ctx.translate(cx, cy); ctx.rotate((-22 * Math.PI) / 180);
      ctx.strokeStyle = acc(0.35 + 0.6 * prep); ctx.lineWidth = 1.6; ctx.shadowColor = acc(0.9); ctx.shadowBlur = 10 + 20 * prep;
      ctx.beginPath(); ctx.ellipse(0, 0, rx, ry, 0, Math.PI * 1.5, Math.PI * 1.5 + p * 6.283); ctx.stroke(); ctx.restore();
    }
    // shockwaves
    for (let i = shocks.length - 1; i >= 0; i--) {
      const w = shocks[i]; w.r += w.v * dt; w.a *= Math.exp(-dt * 1.7);
      if (w.a < 0.015 || w.r > maxR * 1.2) { shocks.splice(i, 1); continue; }
      ctx.lineWidth = w.w; ctx.strokeStyle = acc(w.a.toFixed(3)); ctx.beginPath(); ctx.arc(cx, cy, w.r, 0, 6.283); ctx.stroke();
      ctx.lineWidth = w.w * 0.4; ctx.strokeStyle = `rgba(53,214,255,${(w.a * 0.7).toFixed(3)})`; ctx.beginPath(); ctx.arc(cx, cy, w.r * 0.93, 0, 6.283); ctx.stroke();
    }
    // particles
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i]; p.l += dt; if (p.l > p.m) { parts.splice(i, 1); continue; }
      const damp = Math.exp(-dt * 2.2); p.vx *= damp; p.vy *= damp; p.x += p.vx * dt; p.y += p.vy * dt;
      const k = 1 - p.l / p.m; ctx.fillStyle = `rgba(210,220,255,${(k * 0.9).toFixed(3)})`; ctx.shadowColor = acc(0.9); ctx.shadowBlur = 8;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r * (0.5 + k), 0, 6.283); ctx.fill();
    }
    ctx.shadowBlur = 0;
    if (flash > 0.01) { const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, maxR * 0.9); g.addColorStop(0, `rgba(255,255,255,${(flash * 0.9).toFixed(3)})`); g.addColorStop(0.35, acc((flash * 0.35).toFixed(3))); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); }

    raf = requestAnimationFrame(frame);
  }

  function finish(skipped) {
    if (finished) return; finished = true; cancelAnimationFrame(raf);
    if (skipped) { try { audio.pause(); } catch {} }
    boot.classList.add("done"); document.body.classList.remove("booting");
    renderApps(); setTimeout(() => sfx("ready"), 500);
    setTimeout(() => boot.remove(), 1300);
  }

  function start() {
    if (started) return;
    started = true; t0 = performance.now(); boot.classList.remove("gate");
    ent.speed = 0.5;
    const p = audio.play(); if (p && p.catch) p.catch(() => { t0 = performance.now(); }); // silent fallback keeps the visuals going
    audio.addEventListener("ended", () => finish());
  }
  $("#boot-start").addEventListener("click", start);
  addEventListener("keydown", (e) => { if (!started && (e.key === "Enter" || e.key === " ")) start(); else if (started && e.key === "Escape") finish(true); });
  $("#boot-skip").addEventListener("click", (e) => { e.stopPropagation(); finish(true); });
  raf = requestAnimationFrame(frame);
})();
